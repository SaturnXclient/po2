export const gradientText = 'bg-clip-text text-transparent bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600';
export const gradientBg = 'bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600';
export const gradientHover = 'hover:from-purple-700 hover:via-pink-700 hover:to-blue-700';